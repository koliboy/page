try {
    [localStorage,sessionStorage,setInterval]
   }catch(err){
        alert(err+"Or  allow  coockies or  use  browser chorme,firefox,etc")
   }  