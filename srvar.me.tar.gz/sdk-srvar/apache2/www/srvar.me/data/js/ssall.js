function ss(a){return document.querySelector(a)}
function all(x){return document.querySelectorAll(x)} 
    